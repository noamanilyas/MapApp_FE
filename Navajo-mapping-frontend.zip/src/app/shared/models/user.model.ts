export class User {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}
export class UserAuth {
    token: string;
    name: string;
    admin: boolean;
    id: BigInteger;
}
