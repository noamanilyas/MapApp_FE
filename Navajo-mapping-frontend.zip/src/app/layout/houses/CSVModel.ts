export class CSVRecord {  
	public code: any;  
	public lat: any;  
	public long: any;  
	public elevation: any;  
	public position: any;  
	public owner: any;     
	public strucType: any;     
	public height: any;     
	public city: any;     
	public state: any;     
	public ZIP: any;     
	public county: any;     
	public plusCode: any;     
} 